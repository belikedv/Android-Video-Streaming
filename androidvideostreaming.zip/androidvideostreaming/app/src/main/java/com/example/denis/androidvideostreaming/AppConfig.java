package com.example.denis.androidvideostreaming;

public class AppConfig {
    public static final String STREAM_URL = "rtsp://192.168.99.1:1935/live/myStream";
    public static final String PUBLISHER_USERNAME = "root";
    public static final String PUBLISHER_PASSWORD = "123456";
}
